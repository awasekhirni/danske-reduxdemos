import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YearlytaxstatementComponent } from './yearlytaxstatement.component';

describe('YearlytaxstatementComponent', () => {
  let component: YearlytaxstatementComponent;
  let fixture: ComponentFixture<YearlytaxstatementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YearlytaxstatementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YearlytaxstatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
