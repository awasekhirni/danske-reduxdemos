import { ID } from '@datorama/akita';
import { Injectable } from '@angular/core';
import { timer } from 'rxjs';
import { mapTo } from 'rxjs/operators';
import { ProductStore } from './products.store';
import {products} from './../data/products.data';
import {Product} from './product.model';

@Injectable({ providedIn: 'root' })
export class ProductService {
  constructor(private productStore: ProductStore) {}

  getProducts() {
    timer(1000)
      .pipe(mapTo(products))
      .subscribe(products => {
        this.productStore.set(products);
      });
  }

  getProduct(id: ID) {
    const product = products.find(current => +current.id === +id);

    timer(50)
      .pipe(mapTo(product))
      .subscribe(product => {
        this.productStore.add(product);
      });
  }
}
