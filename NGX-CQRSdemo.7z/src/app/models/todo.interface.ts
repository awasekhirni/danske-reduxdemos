// tslint:disable-next-line:no-empty-interface
export interface Todo{
userId:number;
id:number;
subject:string;
title:string;
description:string;
status:string;
completed:boolean;
}
