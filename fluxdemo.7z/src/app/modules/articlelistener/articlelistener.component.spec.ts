import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticlelistenerComponent } from './articlelistener.component';

describe('ArticlelistenerComponent', () => {
  let component: ArticlelistenerComponent;
  let fixture: ComponentFixture<ArticlelistenerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticlelistenerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticlelistenerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
