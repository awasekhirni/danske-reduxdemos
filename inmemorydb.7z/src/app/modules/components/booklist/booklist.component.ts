import { Component, OnInit } from '@angular/core';
import { BookService } from '../../services/book.service';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  bookslist: any;

  constructor(private bs:BookService) { }

  ngOnInit() {
    this.bs.getBooks().subscribe((results)=>{
      this.bookslist=results;
      console.log(this.bookslist);
    });
  }



}
