import { Component, OnInit } from '@angular/core';
import { InitialState } from '../../store/reducer';
import { ProductService } from '../../services/product.service';
import { NgRedux, select } from '@angular-redux/store';
import { Product } from '../../models/product.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  @select('items') items$:Observable<Array<Product>>;
  constructor(private ngRedux:NgRedux<InitialState>,private ps:ProductService) { }

  ngOnInit() {
    this.ps.fetchAll();
  }

}
