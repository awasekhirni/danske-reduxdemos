import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


import {HttpClient,HttpResponse,HttpHeaders} from '@angular/common/http';
import { Car } from '../models/car.model';
import { map, switchMap, debounceTime, distinctUntilChanged, filter } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CarService {
  //private headers = new Headers({ 'Content-Type': 'application/json' });
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  private carsUrl = 'api/cars';

  constructor(private http:HttpClient,private router:Router) { }



  getCars():Promise<Car[]>{
    return this.http.get(this.carsUrl)
          .toPromise()
          .then((response: HttpResponse<any>)=>{response})
          .catch(this.handleError);
  }

  getCar(id:number):Promise<Car>{
    const url='$this.carsUrl/${id}';
    return this.http.get(url)
          .toPromise()
          .then((response: HttpResponse<any>)=>response)
          .catch(this.handleError);
  }

  createCar(car: Car): Promise<Car> {
    return this.http
      .post(this.carsUrl, JSON.stringify(car), { headers: this.headers })
      .toPromise()
      .then((res:HttpResponse<any>) => res)
      .catch(this.handleError);
  }

  updateCar(car: Car): Promise<Car> {
    const url = `${this.carsUrl}/${car.id}`;
    return this.http
      .put(url, JSON.stringify(car), { headers: this.headers })
      .toPromise()
      .then(() => car)
      .catch(this.handleError);
  }

  removeCar(car: Car): Promise<void> {
    const url = `${this.carsUrl}/${car.id}`;
    return this.http.delete(url, { headers: this.headers })
      .toPromise()
      .then(() => null)
      .catch(this.handleError);
  }



  handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }





}
