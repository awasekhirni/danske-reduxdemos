import { BrowserModule } from '@angular/platform-browser';
import { NgModule,isDevMode} from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './modules/ecom/components/header/header.component';
import { HomeComponent } from './modules/ecom/components/home/home.component';
import { NgReduxModule, NgRedux, DevToolsExtension } from '@angular-redux/store';
import { ProductListComponent } from './modules/ecom/components/product-list/product-list.component';
import { ProductComponent } from './modules/ecom/components/product/product.component';
import { ProductService } from './modules/ecom/services/product.service';
import { RouterModule } from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { setinitialState, InitialState, OnlineShopReducer } from './modules/ecom/store/reducer';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    ProductListComponent,
    ProductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,RouterModule,HttpClientModule,NgReduxModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule {

  constructor(ngRedux:NgRedux<InitialState>, devTools: DevToolsExtension){
    var enhancers = isDevMode()?[devTools.enhancer()]:[];
    ngRedux.configureStore(OnlineShopReducer,setinitialState,[],enhancers);
  }



}
