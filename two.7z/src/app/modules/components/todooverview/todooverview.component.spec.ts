import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TodooverviewComponent } from './todooverview.component';

describe('TodooverviewComponent', () => {
  let component: TodooverviewComponent;
  let fixture: ComponentFixture<TodooverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TodooverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TodooverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
