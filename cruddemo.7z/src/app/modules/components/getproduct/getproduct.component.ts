import { ProductService } from './../../services/product.service';
import { Component, OnInit } from '@angular/core';
import Product from '../../models/product.model';

@Component({
  selector: 'app-getproduct',
  templateUrl: './getproduct.component.html',
  styleUrls: ['./getproduct.component.css']
})
export class GetproductComponent implements OnInit {
  productsList: Product[];

  constructor(private ps:ProductService) { }

  ngOnInit() {
    this.ps.getProducts()
          .subscribe((results:Product[])=>{
            this.productsList=results;
          });

  }

  deleteProduct(id) {
    this.ps.deleteProduct(id).subscribe(res => {
      this.productsList.splice(id, 1);
    });
  }



}
