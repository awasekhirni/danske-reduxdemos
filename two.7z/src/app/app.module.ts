import { IAppState } from './modules/sar/appstate.interface';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule,isDevMode } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms'
import {NgRedux,NgReduxModule, DevToolsExtension} from '@angular-redux/store';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { rootReducer,INITIAL_STATE } from './modules/sar/store';
import { TodolistComponent } from './modules/components/todolist/todolist.component';
import { TodooverviewComponent } from './modules/components/todooverview/todooverview.component';
import {fromJS,Map} from 'immutable';
//npm install --save immutable

@NgModule({
  declarations: [
    AppComponent,
    TodolistComponent,
    TodooverviewComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    NgReduxModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {

  // constructor(ngRedux:NgRedux<Map<string,any>>,devTools:DevToolsExtension){
  //   //initializing the ngRedux
  //   var enhancers=isDevMode()?[devTools.enhancer()]:[];
  //   ngRedux.configureStore(rootReducer,fromJS(INITIAL_STATE),[],enhancers);
  // }
  constructor(ngRedux: NgRedux<IAppState>) {
    ngRedux.configureStore(rootReducer, INITIAL_STATE);
  }

 }
