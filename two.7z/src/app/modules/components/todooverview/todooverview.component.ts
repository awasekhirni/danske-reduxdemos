import { Component, OnInit } from '@angular/core';
import { select, NgRedux } from '@angular-redux/store';
import { IAppState } from '../../sar/appstate.interface';
import { REMOVE_ALL_TODOS } from '../../sar/actions';

@Component({
  selector: 'app-todooverview',
  templateUrl: './todooverview.component.html',
  styleUrls: ['./todooverview.component.css']
})
export class TodooverviewComponent implements OnInit {
  @select() todos;
  @select() lastUpdate;

  constructor(private ngRedux:NgRedux<IAppState>) { }

  ngOnInit() {
  }

  clearTodos(){
    this.ngRedux.dispatch({type:REMOVE_ALL_TODOS})
  }
}
