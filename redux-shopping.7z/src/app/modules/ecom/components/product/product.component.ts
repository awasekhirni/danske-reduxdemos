import { Component, OnInit, Input } from '@angular/core';
import { InitialState } from '../../store/reducer';
import { NgRedux } from '@angular-redux/store';
import { AddToCart, RemoveFromCart } from '../../store/actions';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  inCart=false;
  @Input() product:Product;

  constructor(private ngRedux:NgRedux<InitialState>) { }

  ngOnInit() {
  }

  addToCart(item:Product){
    this.ngRedux.dispatch(AddToCart(item));
    this.inCart=true;
  }
  removeFromCart(item:Product){
    this.ngRedux.dispatch(RemoveFromCart(item));
    this.inCart=false;
  }

}
