import { Component, ViewChild } from '@angular/core';
import { TabsmileComponent } from './components/tabpresentation/tabsmile.component';
import { TablistComponent } from './components/tabpresentation/tablist.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  @ViewChild('stockEdit') editStockTemplate;
  @ViewChild(TablistComponent) tabslist;
  constructor(){}
  allstocks = [
    {
      id: 1,
      stockname: 'National Thermal Power Corporation',
      stockabbreviation: 'NTPC',
      price: '157'
    }
  ];

  onEditStock(stock) {
    this.tabslist.openTab(
      `Editing ${stock.stockname}`,
      this.editStockTemplate,
      stock,
      true
    );
  }

  onAddStock() {
    this.tabslist.openTab('New Stock', this.editStockTemplate, {}, true);
  }

  onStockFormSubmit(dataModel) {
    if (dataModel.id > 0) {
      this.allstocks = this.allstocks.map(stock => {
        if (stock.id === dataModel.id) {
          return dataModel;
        } else {
          return stock;
        }
      });
    } else {
      // create a new one
      dataModel.id = Math.round(Math.random() * 100);
      this.allstocks.unshift(dataModel);
    }

    // close the tab
    this.tabslist.closeActiveTab();
  }

  
}
