export class Book{

  constructor(public author:string,public country:string,public imageLink:string,public language:string,public link:string,public pages:number, public title:string,public year:number){

    this.author=author;
    this.country=country;
    this.imageLink=imageLink;
    this.language=language;
    this.link=link;
    this.pages=pages;
    this.title=title;
    this.year=year;

  }
}
