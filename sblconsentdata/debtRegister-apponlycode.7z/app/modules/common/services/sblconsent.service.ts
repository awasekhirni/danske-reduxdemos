import { HttpClientModule,HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class SBLConsentService {
  debtRegisterUrl='https://raw.githubusercontent.com/awasekhirni/danske-reduxdemos/master/sblconsentdata/DebtRegister_Danske.json';
  cioUrl='';

  constructor(private http: HttpClient) { }

  getAllDebtRegister(){
    return this.http.get(this.debtRegisterUrl);
  }
}
