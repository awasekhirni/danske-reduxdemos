import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DebtregisterComponent } from './debtregister.component';

describe('DebtregisterComponent', () => {
  let component: DebtregisterComponent;
  let fixture: ComponentFixture<DebtregisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DebtregisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DebtregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
