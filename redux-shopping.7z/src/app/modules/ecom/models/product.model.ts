export interface Product{
  name:string,
  image:string,
  description:string,
  category:string,
  price:string,
  quantity:string,
  shipping:string,
  location:string,
  color:string,
  link:string
}
