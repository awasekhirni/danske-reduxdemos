import { SBLConsentService } from './../../services/sblconsent.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerincomeoverview',
  templateUrl: './customerincomeoverview.component.html',
  styleUrls: ['./customerincomeoverview.component.css']
})
export class CustomerincomeoverviewComponent implements OnInit {
  customers: any;

  constructor(private svc:SBLConsentService) { }

  ngOnInit() {
    return this.svc.getAllCustomerIncomeData().subscribe(results=>{
      this.customers=results;
      console.log(this.customers);
    });
  }

}
