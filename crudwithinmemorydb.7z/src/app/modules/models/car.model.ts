export class Car{
    constructor(public id:number, public model:String,public manufacturer:string, public fuelType:string, public price:number ){
      this.id=id;
      this.model=model;
      this.manufacturer=manufacturer;
      this.fuelType=fuelType;
      this.price=price;
    }
}
