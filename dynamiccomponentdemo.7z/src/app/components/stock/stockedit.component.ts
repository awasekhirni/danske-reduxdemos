import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-stockedit',
  templateUrl: './stockedit.view.html'
})
export class StockEditComponent implements OnInit {
    stockForm: FormGroup;

  @Input() stock;
  @Output() saveStock = new EventEmitter<any>();
    

  constructor(private fb: FormBuilder) {
    this.stockForm = this.fb.group({
      id: '',
      stockname: '',
      stockabbreviation: '',
      price: ''
    });
  }

  ngOnInit() {
    this.stockForm.setValue({
      id: this.stock.id || -1,
      stockname: this.stock.stockname || '',
      stockabbreviation: this.stock.stockabbreviation || '',
      price: this.stock.price || ''
    });
  }

  onStockFormSubmit() {
    let dataModel = this.stockForm.value;
    this.saveStock.emit(dataModel);
    console.log(dataModel);
  }
}