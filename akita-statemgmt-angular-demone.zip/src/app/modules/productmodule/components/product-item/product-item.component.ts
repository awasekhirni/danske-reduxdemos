import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {ProductQuery} from '../../state/product.query'; 
import {ProductService} from '../../state/products.service';
@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent implements OnInit {

  product$=this.productQuery.selectEntity(this.productId);

  constructor(
    private activatedRoute:ActivatedRoute,
    private productService:ProductService,
    private productQuery:ProductQuery
  ) { }

  ngOnInit() {
    if(this.productQuery.hasEntity(this.productId)===false){
      this.productService.getProduct(this.productId);
    }
  }

  get productId(){
    return this.activatedRoute.snapshot.params.id;
  }

}
