import { SBLConsentService } from './../../services/sblconsent.service';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-debtregister',
  templateUrl: './debtregister.component.html',
  styleUrls: ['./debtregister.component.css']
})
export class DebtregisterComponent implements OnInit {
  debts: any;

  constructor(private sblcs: SBLConsentService) { }

  ngOnInit() {
    this.sblcs.getAllDebtRegister().subscribe(results => {this.debts = results;

      console.log(this.debts);

    });

  }

}
