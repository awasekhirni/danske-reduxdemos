import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateproductComponent } from './modules/components/createproduct/createproduct.component';
import { GetproductComponent } from './modules/components/getproduct/getproduct.component';
import { EditproductComponent } from './modules/components/editproduct/editproduct.component';
import { DeleteproductComponent } from './modules/components/deleteproduct/deleteproduct.component';
import { HomeComponent } from './modules/components/home/home.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { ProductService } from './modules/services/product.service';

@NgModule({
  declarations: [
    AppComponent,
    CreateproductComponent,
    GetproductComponent,
    EditproductComponent,
    DeleteproductComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule,
    FormsModule,ReactiveFormsModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
