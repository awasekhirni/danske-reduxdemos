import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule } from '@angular/common/http';
import { HttpClientInMemoryWebApiModule, InMemoryDbService, } from 'angular-in-memory-web-api';
import { InMemoryDataService } from './modules/server/inmemory.service';
import { BooklistComponent } from './modules/components/booklist/booklist.component';
import { BookService } from './modules/services/book.service';
import { BookComponent } from './modules/components/book/book.component';

@NgModule({
  declarations: [
    AppComponent,
    BooklistComponent,
    BookComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    HttpClientInMemoryWebApiModule.forRoot(
      InMemoryDataService, { dataEncapsulation: false }
    ),
  ],
  providers: [BookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
