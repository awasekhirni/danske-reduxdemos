import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Todo } from '../models/todo.interface';

@Injectable()
export class TodoService {
  baseUrl='http://localhost:4000/todotasks/';
  constructor(private http:HttpClient) { }

    fetchTodos(){
      return this.http.get<Todo[]>(this.baseUrl);
    }

    deleteTodo(id:number){
      return this.http.delete(this.baseUrl+'${id}');
    }

    addTodo(payload:Todo){
      return this.http.post<Todo>(this.baseUrl,payload);
    }

    updateTodo(payload:Todo,id:number){
      return this.http.put<Todo>(this.baseUrl+'${id}',payload);
    }



}
