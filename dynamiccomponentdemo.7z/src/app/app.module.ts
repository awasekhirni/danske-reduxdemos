import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { TabSmileDirective } from './directives/tabsmile.directive';
import { TabsmileComponent } from './components/tabpresentation/tabsmile.component';
import { TablistComponent } from './components/tabpresentation/tablist.component';
import { StockEditComponent } from './components/stock/stockedit.component';
import { StockListComponent } from './components/stock/stocklist.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';


@NgModule({
  declarations: [
    AppComponent,TabsmileComponent,TablistComponent,TabSmileDirective,StockEditComponent,StockListComponent
  ],
  imports: [
    BrowserModule,ReactiveFormsModule,FormsModule,CommonModule
  ],
  //dynamic components are registered here 
  entryComponents:[TabsmileComponent],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
