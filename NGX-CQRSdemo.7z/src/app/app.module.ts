import { TodotaskslistComponent } from './components/todotaskslist/todotaskslist.component';
import { TodotaskformComponent } from './components/todotaskform/todotaskform.component';
import { TodoState } from './states/todo.state';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import {NgxsModule} from '@ngxs/store';
import {NgxsReduxDevtoolsPluginModule} from '@ngxs/devtools-plugin';
import {NgxsLoggerPluginModule} from '@ngxs/logger-plugin';
import 'rxjs';
import {ReactiveFormsModule} from '@angular/forms';
import { TodoService } from './services/todo.service';

@NgModule({
  declarations: [
    AppComponent,
    TodotaskformComponent,
    TodotaskslistComponent
  ],
  imports: [
    BrowserModule,
    NgxsModule.forRoot([
      TodoState
  ]),
  NgxsReduxDevtoolsPluginModule.forRoot(),
  NgxsLoggerPluginModule.forRoot(),
  HttpClientModule,
  ReactiveFormsModule,

    AppRoutingModule
  ],
  providers: [TodoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
