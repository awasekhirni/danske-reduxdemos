import { Component, OnInit } from '@angular/core';
import { Todo } from '../../models/todo.interface';
import { DeleteTodo, SetSelectedTodo, GetTodos } from '../../actions/todo.actions';
import { Store, Select } from '@ngxs/store';
import { Observable } from 'rxjs';
import { TodoState } from '../../states/todo.state';

@Component({
  selector: 'app-todotaskslist',
  templateUrl: './todotaskslist.component.html',
  styleUrls: ['./todotaskslist.component.scss']
})
export class TodotaskslistComponent implements OnInit {

  @Select(TodoState.getTodoList) todos: Observable<Todo[]>;

  constructor(private store: Store) {
  }

  ngOnInit() {
      this.store.dispatch(new GetTodos());
  }

  deleteTodo(id: number) {
      this.store.dispatch(new DeleteTodo(id));
  }

  editTodo(payload: Todo) {
      this.store.dispatch(new SetSelectedTodo(payload));
  }

}
