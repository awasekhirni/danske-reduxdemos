import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerincomeoverview',
  templateUrl: './customerincomeoverview.component.html',
  styleUrls: ['./customerincomeoverview.component.css']
})
export class CustomerincomeoverviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
