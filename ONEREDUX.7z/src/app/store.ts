import { INCREMENT, DECREMENT } from './actions';

//define the state model
export interface IAppState{
  counter:number;
}

//define the initial state
export const INITIAL_STATE:IAppState={
  counter:0
}

//root reducer takes in current state and action as input
// returns a new state based on the action.
export function rootReducer(state:IAppState,action):IAppState{
  switch(action.type){
    case INCREMENT:
      return{
        counter:state.counter+1
      };
    case DECREMENT:
      return{
        counter:state.counter-1
      };
  }
  return state;
}
