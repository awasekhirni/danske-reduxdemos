import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { NgRedux } from "@angular-redux/store";
import { InitialState } from "../store/reducer";
import { getAllLifecycleHooks } from "@angular/compiler/src/lifecycle_reflector";
import { Product } from "../models/product.model";
import { LoadItems } from "../store/actions";

@Injectable({
  providedIn: "root"
})
export class ProductService {
  constructor(
    private http: HttpClient,
    private ngRedux: NgRedux<InitialState>
  ) {}

  fetchAll() {
    this.http
      .get("http://localhost:4000/products")
      .subscribe((products: Array<Product>) => {
        this.ngRedux.dispatch(LoadItems(products));
      });
  }
}
