import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductItemComponent } from '../../productmodule/components/product-item/product-item.component';
import { ProductListComponent } from '../../productmodule/components/product-list/product-list.component';

const routes: Routes = [
    { path: '',pathMatch:'full',redirectTo:'products'},
  { path: 'products/:id', component: ProductItemComponent },
  { path: 'products', component: ProductListComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
