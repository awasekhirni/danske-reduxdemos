import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';

@Injectable()
export class CarInMemoryDbService {

  constructor() { }

  createDb(){
    let cars=[
      { id:123123, model:"Elantra",manufacturer:"Hyundai", fuelType:"petrol", price:2800000},
      { id:3241, model:"Vento",manufacturer:"Volkswagen", fuelType:"petrol", price:1600000},
      { id:54332, model:"Camry",manufacturer:"Toyota", fuelType:"petrol", price:2900000},
    ];
    return { cars };
  }

}
