import { CarService } from './../../services/car.service';
import { Component, OnInit } from '@angular/core';
import { Car } from '../../models/car.model';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-carlist',
  templateUrl: './carlist.component.html',
  styleUrls: ['./carlist.component.css']
})
export class CarlistComponent implements OnInit {
  cars:Car[];
  selectedCar:Car;
  newCar:Car;

  constructor(private cs:CarService,private router:Router) { }

  ngOnInit() {
    this.cs.getCars().then((results:any)=>{this.cars=results});
    this.newCar = new Car(123123,"Mercedes c20","daimler","diesel",3200000);
  }

  createCar(car:Car):void{
    this.cs.createCar(car).then(car=>{
      this.cars.push(car);
      this.selectedCar=null;
    });
  }

  deleteCar(car:Car):void{
    this.cs.removeCar(car)
      .then(()=>{
        this.cars=this.cars.filter(c=>c!==car);
        if(this.selectedCar===car){
          this.selectedCar=null;
        }
      });
  }


  showInfo(car:Car):void{
    this.selectedCar=car;
    this.router.navigate(['/details', this.selectedCar.id]);
  }

}
