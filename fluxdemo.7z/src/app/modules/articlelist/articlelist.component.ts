import { Component, OnInit, } from '@angular/core';
import { Article } from '../models/article.model';

@Component({
  selector: 'app-articlelist',
  templateUrl: './articlelist.component.html',
  styleUrls: ['./articlelist.component.css']
})
export class ArticlelistComponent implements OnInit {
  listofarticles: Article[];



  constructor() {
    //state management using angular
    //stateful component
    this.listofarticles=[
      new Article(3212312,"NPA data not shared by RBI","Das","Scroll","Govt Fraud",new Date(),false),
      new Article(3212312,"Leila","Gupta","Scroll","NetFlix",new Date(),false),
    ];
   }

   addArticle(myarticle:Article){
     this.listofarticles.unshift(myarticle);

   }

  ngOnInit() {
  }

}
