import { NgRedux,select} from '@angular-redux/store';
import { Component, OnInit } from '@angular/core';
import { IAppState } from '../../sar/appstate.interface';
import { REMOVE_TODO, TOGGLE_TODO, ADD_TODO } from '../../sar/actions';
import { ITodo } from '../../models/todo.model';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.css']
})
export class TodolistComponent implements OnInit {

  @select() todos;

  //new object instance for default loading
  newObj:ITodo={
    id:0,
    description:"",
    responsible:"",
    category:"",
    priority:"medium",
    isCompleted:false
  }

  constructor(private ngRedux: NgRedux<IAppState>) { }

  ngOnInit() {
  }

  onSubmit(){
    this.ngRedux.dispatch({type:ADD_TODO,todo:this.newObj});
  }

  toggleTodo(todo){
    this.ngRedux.dispatch({type:TOGGLE_TODO,id:todo.id});

  }

  removeTodo(todo){
    this.ngRedux.dispatch({type:REMOVE_TODO,id:todo.id});
  }

}
