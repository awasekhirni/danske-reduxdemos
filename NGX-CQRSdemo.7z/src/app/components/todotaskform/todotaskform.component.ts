import { TodoState } from './../../states/todo.state';
import { SetSelectedTodo, AddTodo, UpdateTodo } from './../../actions/todo.actions';
import { Component, OnInit } from "@angular/core";
import {FormBuilder,FormGroup,Validators} from '@angular/forms';

import {ActivatedRoute,Router} from '@angular/router';
import {Observable} from 'rxjs';
import {Select,Store} from '@ngxs/store';
import { Todo } from '../../models/todo.interface';


@Component({
  selector: "app-todotaskform",
  templateUrl: "./todotaskform.component.html",
  styleUrls: ["./todotaskform.component.scss"]
})
export class TodotaskformComponent implements OnInit {
  @Select(TodoState.getSelectedTodo) selectedTodo: Observable<Todo>;
  todoForm: FormGroup;
  editTodo = false;

  constructor(private fb: FormBuilder, private store: Store, private route: ActivatedRoute, private router: Router) {
      this.createForm();
  }

  ngOnInit() {
      this.selectedTodo.subscribe(todo => {
          if (todo) {
              this.todoForm.patchValue({
                  id: todo.id,
                  userId: todo.userId,
                  title: todo.title,
                  subject:todo.subject,
                  description:todo.description,
                  status:todo.status,
                  completed:todo.completed

              });
              this.editTodo = true;
          } else {
              this.editTodo = false;
          }
      });
  }

  createForm() {
      this.todoForm = this.fb.group({
          id: [''],
          userId: ['', Validators.required],
          title: ['', Validators.required],
          subject:['', Validators.required],
          description:['', Validators.required],
          status:['', Validators.required],
          completed:['',Validators.required]

      });
  }

  onSubmit() {
      if (this.editTodo) {
          this.store.dispatch(new UpdateTodo(this.todoForm.value, this.todoForm.value.id)).subscribe(() => {
              this.clearForm();
          });
      } else {
          this.store.dispatch(new AddTodo(this.todoForm.value)).subscribe(() => {
              this.clearForm();
          });
      }
  }

  clearForm() {
      this.todoForm.reset();
      this.store.dispatch(new SetSelectedTodo(null));
  }
}
