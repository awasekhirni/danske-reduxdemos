import { Article } from './../models/article.model';
import { Component, OnInit,Input,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-articlelistener',
  templateUrl: './articlelistener.component.html',
  styleUrls: ['./articlelistener.component.css']
})
export class ArticlelistenerComponent implements OnInit {
  // listener (subscriber)
  @Input('news-listener1') data:Article;
  constructor() { }

  ngOnInit() {
  }

}
