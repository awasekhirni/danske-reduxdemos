export interface ITodo{
  id:number;
  description:string;
  category:string;
  responsible:string;
  priority:string;
  isCompleted:boolean;
}
