import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-incomeperemployer',
  templateUrl: './incomeperemployer.component.html',
  styleUrls: ['./incomeperemployer.component.css']
})
export class IncomeperemployerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
