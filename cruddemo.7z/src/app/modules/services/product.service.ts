import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  productUrl = 'http://localhost:4000/products';

  constructor(private http: HttpClient) { }

  addProduct(productName, productDescription, productPrice,productIsactive) {
    console.log(productName, productDescription, productPrice,productIsactive);
    const obj = {
      productName,
      productDescription,
      productPrice,
      productIsactive
    };
    this.http.post(`${this.productUrl}/add`, obj)
        .subscribe(res => console.log('Done'));
  }

  getProducts() {
    return this
           .http
           .get(`${this.productUrl}`);
  }

  editProduct(id) {
    return this
            .http
            .get(`${this.productUrl}/edit/${id}`);
  }

  updateProduct(productName, productDescription, productPrice,productIsactive, id) {
    const obj = {
      productName,
      productDescription,
      productPrice,productIsactive
    };
    this
      .http
      .post(`${this.productUrl}/update/${id}`, obj)
      .subscribe(res => console.log('Update Complete'));
  }

  deleteProduct(id) {
    return this
              .http
              .get(`${this.productUrl}/delete/${id}`);
  }
}
