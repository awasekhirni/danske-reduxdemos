export class Article{



  constructor(public articleId:number,public aTitle:string, public aAuthor:string, public aEditor:string, public aClassification:string, public aPublish:Date, public archive:boolean){
    this.articleId=articleId;
    this.aTitle=aTitle;
    this.aAuthor=aAuthor;
    this.aEditor=aEditor;
    this.aClassification=aClassification;
    this.aPublish=aPublish;
    this.archive=archive;
  }
}
