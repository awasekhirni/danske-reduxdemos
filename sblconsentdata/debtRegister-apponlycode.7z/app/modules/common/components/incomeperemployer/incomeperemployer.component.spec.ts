import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeperemployerComponent } from './incomeperemployer.component';

describe('IncomeperemployerComponent', () => {
  let component: IncomeperemployerComponent;
  let fixture: ComponentFixture<IncomeperemployerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncomeperemployerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncomeperemployerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
