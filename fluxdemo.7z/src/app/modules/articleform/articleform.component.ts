import { Component, OnInit,Output,EventEmitter,ViewEncapsulation } from '@angular/core';
import { Article } from '../models/article.model';

@Component({
  selector: 'app-articleform',
  templateUrl: './articleform.component.html',
  styleUrls: ['./articleform.component.css'],
  encapsulation:ViewEncapsulation.Emulated,
})
export class ArticleformComponent implements OnInit {

  //newObj= new Article();
  @Output() generateNews =new EventEmitter<Article>()
  constructor() { }

  ngOnInit() {
  }

  //methods used to bind to event
  //publisher event //dispatch
  createNews(articleId:number,aTitle:string,aAuthor:string,aEditor:string,aPublish:Date,aClassification:string,archive:boolean){

  this.generateNews.emit(new Article(articleId,aTitle,aAuthor,aEditor,aClassification,aPublish,archive));

  }


}
