import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-editproduct',
  templateUrl: './editproduct.component.html',
  styleUrls: ['./editproduct.component.css']
})
export class EditproductComponent implements OnInit {

  editForm: FormGroup;
  product: any = {};

  constructor(private route: ActivatedRoute, private router: Router, private ps: ProductService, private fb: FormBuilder) {
      this.generateForm();
 }

 generateForm(){
  this.editForm=this.fb.group({
    productName:['',Validators.required],
    productDescription:['',Validators.required],
    productPrice:['',Validators.required],
    productIsactive:['',Validators.required],
  })
}

  ngOnInit() {
    this.route.params.subscribe(params => {
        this.ps.editProduct(params.id).subscribe(res => {
          this.product = res;
      });
    });
  }

  updateProduct(productName, productDescription, productPrice, productIsactive,id) {
    this.route.params.subscribe(params => {
      this.ps.updateProduct(productName, productDescription, productPrice, productIsactive,params.id);
      this.router.navigate(['products']);
    });
  }
}
