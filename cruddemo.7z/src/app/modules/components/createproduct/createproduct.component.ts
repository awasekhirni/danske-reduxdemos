import { ProductService } from './../../services/product.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import Product from '../../models/product.model';

@Component({
  selector: 'app-createproduct',
  templateUrl: './createproduct.component.html',
  styleUrls: ['./createproduct.component.css']
})
export class CreateproductComponent implements OnInit {

  createForm:FormGroup;
  constructor(private fb:FormBuilder, private ps:ProductService) {
    this.generateForm();
   }

   generateForm(){
     this.createForm=this.fb.group({
       productName:['',Validators.required],
       productDescription:['',Validators.required],
       productPrice:['',Validators.required],
       productIsactive:['',Validators.required],
     })
   }

   addProduct(productName,productDescription,productPrice,productIsactive){
     this.ps.addProduct(productName,productDescription,productPrice,productIsactive);
   }

  ngOnInit() {
  }

}
