import { Component, OnInit } from '@angular/core';
import { Product } from '../../state/product.model';
import { Observable } from 'rxjs';
import {FormControl} from '@angular/forms';
import {switchMap,startWith,tap} from 'rxjs/operators';
import {ProductQuery} from '../../state/product.query';
import { ProductService } from '../../state/products.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
products$:Observable<Product[]>;
selectLoading$:Observable<boolean>;
sortControl=new FormControl('price');
  constructor(private _pq:ProductQuery, private _ps:ProductService) { }

  ngOnInit() {
    this.products$= this.sortControl.valueChanges.pipe(
      startWith<keyof Product>('price'),
      switchMap(sortBy=>{
        return this._pq.selectAll({sortBy:sortBy});
      })
    ); 
    this.selectLoading$=this._pq.selectLoading();
    this.fetchRecords();

  }

  fetchRecords(){
    if(this._pq.isPristine){
      this._ps.getProducts();
    }
  }
  

}
