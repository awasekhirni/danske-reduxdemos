import { BrowserModule } from '@angular/platform-browser';
import { NgModule,isDevMode } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgReduxModule, NgRedux,DevToolsExtension } from '@angular-redux/store';
import { INITIAL_STATE, rootReducer, IAppState } from './store';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgReduxModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {

  constructor(ngRedux:NgRedux<IAppState>){
    ngRedux.configureStore(rootReducer,INITIAL_STATE)
  }

  //alternatively
  //constructor(ngRedux:NgRedux<Map<string,any>>,devTools:DevToolsExtension){
  //initializing the ngRedux
  //var enhancers=isDevMode()?[devTools.enhancer()]:[];
  //ngRedux.configureStore(rootReducer,fromJS(INITIAL_state),[],enhancers);
  //}

}
