import { YearlytaxstatementComponent } from './../components/yearlytaxstatement/yearlytaxstatement.component';
import { PayslipsComponent } from './../components/payslips/payslips.component';
import { DashboardComponent } from './../components/dashboard/dashboard.component';
import { LandingpageComponent } from './../components/landingpage/landingpage.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SigninComponent } from '../components/signin/signin.component';
import { SignupComponent } from '../components/signup/signup.component';
import { DebtregisterComponent } from '../components/debtregister/debtregister.component';
import { IncomeperemployerComponent } from '../components/incomeperemployer/incomeperemployer.component';
import { CustomerincomeoverviewComponent } from '../components/customerincomeoverview/customerincomeoverview.component';

const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'home',component:LandingpageComponent,data:{preload:true}},
  {path:'signin',component:SigninComponent,data:{preload:true}},
  {path:'signup',component:SignupComponent,data:{preload:true}},
  {path:'dashboard',component:DashboardComponent,data:{preload:true}},
  {path:'debtregister',component:DebtregisterComponent,data:{preload:true}},
  {path:'cincomeoverview',component:CustomerincomeoverviewComponent,data:{preload:true}},
  {path:'payslips',component:PayslipsComponent,data:{preload:true}},
  {path:'incomeperemployer',component:IncomeperemployerComponent,data:{preload:true}},
  {path:'yearlytax',component:YearlytaxstatementComponent,data:{preload:true}},





]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: [],
})
export class DanskeMainRoutingModule { }
