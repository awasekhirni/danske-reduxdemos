import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { LandingpageComponent } from './modules/common/components/landingpage/landingpage.component';
import { SigninComponent } from './modules/common/components/signin/signin.component';
import { SignupComponent } from './modules/common/components/signup/signup.component';
import { DanskeMainRoutingModule } from './modules/common/routes/main.routes';
import { RouterModule } from '@angular/router';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { DashboardComponent } from './modules/common/components/dashboard/dashboard.component';
import { DebtregisterComponent } from './modules/common/components/debtregister/debtregister.component';
import { CustomerincomeoverviewComponent } from './modules/common/components/customerincomeoverview/customerincomeoverview.component';
import { PayslipsComponent } from './modules/common/components/payslips/payslips.component';
import { IncomeperemployerComponent } from './modules/common/components/incomeperemployer/incomeperemployer.component';
import { YearlytaxstatementComponent } from './modules/common/components/yearlytaxstatement/yearlytaxstatement.component';
import { SBLConsentService } from './modules/common/services/sblconsent.service';

@NgModule({
  declarations: [
    AppComponent,
    LandingpageComponent,
    SigninComponent,
    SignupComponent,
    DashboardComponent,
    DebtregisterComponent,
    CustomerincomeoverviewComponent,
    PayslipsComponent,
    IncomeperemployerComponent,
    YearlytaxstatementComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    DanskeMainRoutingModule
  ],
  providers: [SBLConsentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
