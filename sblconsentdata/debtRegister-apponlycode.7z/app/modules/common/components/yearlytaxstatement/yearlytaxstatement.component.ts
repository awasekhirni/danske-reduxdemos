import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-yearlytaxstatement',
  templateUrl: './yearlytaxstatement.component.html',
  styleUrls: ['./yearlytaxstatement.component.css']
})
export class YearlytaxstatementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
