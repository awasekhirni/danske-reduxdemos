import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TodotaskslistComponent } from './todotaskslist.component';

describe('TodotaskslistComponent', () => {
  let component: TodotaskslistComponent;
  let fixture: ComponentFixture<TodotaskslistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TodotaskslistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TodotaskslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
