import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerincomeoverviewComponent } from './customerincomeoverview.component';

describe('CustomerincomeoverviewComponent', () => {
  let component: CustomerincomeoverviewComponent;
  let fixture: ComponentFixture<CustomerincomeoverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerincomeoverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerincomeoverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
