export default class Product{
    productName:string;
    productDescription:string;
    productPrice:number;
    productIsactive:boolean;
}
