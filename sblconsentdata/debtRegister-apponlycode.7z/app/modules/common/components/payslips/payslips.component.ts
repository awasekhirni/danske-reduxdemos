import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payslips',
  templateUrl: './payslips.component.html',
  styleUrls: ['./payslips.component.css']
})
export class PayslipsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
