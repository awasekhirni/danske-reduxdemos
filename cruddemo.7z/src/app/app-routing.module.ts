import { DeleteproductComponent } from './modules/components/deleteproduct/deleteproduct.component';
import { EditproductComponent } from './modules/components/editproduct/editproduct.component';
import { CreateproductComponent } from './modules/components/createproduct/createproduct.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GetproductComponent } from './modules/components/getproduct/getproduct.component';
import { HomeComponent } from './modules/components/home/home.component';

const routes: Routes = [
  {path:'*',redirectTo:"home",pathMatch:'full'},
  {path:'home',component:HomeComponent,data:{preload:true}},
  {path:'product/create',component:CreateproductComponent,data:{preload:true}},
  {path:'edit/:id',component:EditproductComponent,data:{preload:true}},
  {path:'products',component:GetproductComponent,data:{preload:true}},
  {path:'delete/:id',component:DeleteproductComponent,data:{preload:true}},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
